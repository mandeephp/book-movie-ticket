from django.conf.urls import url,include
from django.contrib import admin

from . import views

urlpatterns = [
    url(r'^$',views.index,name='index'),
    #url(r'^new/',views.new,name='new'),
    url(r'^app/movie/$',views.movie,name='movie'),
    url(r'^app/details/$',views.details,name='details'),
    url(r'^app/register/$',views.register_user,name='register'),
    url(r'^app/contact/$',views.contact,name='contact'),
    url(r'^app/booking/$',views.booking,name='booking'),
    url(r'^app/ongoing/$',views.ongoing,name='ongoing'),
    url(r'^app/upcoming/$',views.upcoming,name='upcoming'),
    url(r'^app/about/$',views.about,name='about'),
    url(r'^register_success/$', views.register_success,name='register_success'),
    url(r'^confirm/(?P<activation_key>\w+)/$', views.register_confirm,name='register_confirm'),
    url(r'^login/',views.login,name='login'),
    url(r'^app/login/$',views.login1,name='login'),
    url(r'^app/trailers/$',views.trailers,name='trailers'),
    url(r'^your_url/?$','app.views.search', name='your_url_name'),
    url(r'^cart/(?P<id>\d+)/$', views.cart, name='cart'),
    url(r'^app/cart/$',views.cart,name='cart'),
    url(r'^app/pay/$',views.pay,name='pay'),
    url(r'^app/payments/$',views.payments,name='payments'),

   
############################ongoing movies##########################
    url(r'^app/civilwar/$',views.civilwar,name='civilwar'),
    url(r'^app/zootopia/$',views.zootopia,name='zootopia'),
    url(r'^app/cloverfieldlane/$',views.cloverfieldlane,name='cloverfieldlane'),
    url(r'^app/moneymonster/$',views.moneymonster,name='moneymonster'),
    url(r'^app/thedarkness/$',views.thedarkness,name='thedarkness'),

    url(r'^app/civilimage/$',views.civilimage,name='civilimage'),
##############################upcoming movies############################################
    url(r'^app/loveandfriendship/$',views.loveandfriendship,name='loveandfriendship'),
    url(r'^app/thelobster/$',views.thelobster,name='thelobster'),
    url(r'^app/waiting/$',views.waiting,name='waiting'),
    url(r'^app/conjuring2/$',views.conjuring2,name='conjuring2'),
    url(r'^app/hourstogo/$',views.hourstogo,name='hourstogo'),
    url(r'^app/startrekbeyond/$',views.startrekbeyond,name='startrekbeyond'),
    url(r'^app/suicidesquad/$',views.suicidesquad,name='suicidesquad'),
    url(r'^app/rustom/$',views.rustom,name='rustom'),







   #url(r'^app/payu/$',views.payu,name='payu'),


    
]

