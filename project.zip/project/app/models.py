from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import datetime
# Create your models here.

""" class Post(models.Model):
     movie_name=models.CharField(max_length=160)
     description=models.TextField(max_length=1000)
     release_date=models.CharField(max_length=50)
     ticket_price=models.CharField(max_length=10)
     image=models.FileField(upload_to='images',blank=True)
      
     def __str__(self):
         return self.movie_name
 
     def __str__(self):
         return self.description
 
     def __str__(self):
         return self.release_date

     def __str__(self):
         return self.ticket_price

     def save(self, *args, **kwargs):
	 super(Post, self).save(*args, **kwargs)
	 filename=self.image.url """




class payment(models.Model):
	card_number=models.IntegerField(max_length=16)
	expiry_date=models.DateTimeField()
	cvv=models.IntegerField(max_length=3)	
	name_on_card=models.CharField(max_length=30)
	def __str__(self):
		return self.name_on_card




class Movie(models.Model):
     movie_name=models.CharField(max_length=160)
     description=models.TextField(max_length=100000)
     release_date=models.DateTimeField()
     ticket_price=models.CharField(max_length=10)
     def __str__(self):
         return self.movie_name

     time=models.TimeField(blank=True, null=True)
     time1=models.TimeField(blank=True, null=True)
     time2=models.TimeField(blank=True, null=True)
     time3=models.TimeField(blank=True, null=True)
     time4=models.TimeField(blank=True, null=True)
     time5=models.TimeField(blank=True, null=True)
     time6=models.TimeField(blank=True, null=True)
     time7=models.TimeField(blank=True, null=True)
     time8=models.TimeField(blank=True, null=True)
     time9=models.TimeField(blank=True, null=True)
    
#    image=models.FileField(upload_to='images',blank=True)
#    model_pic = models.ImageField(upload_to='images/') 
     
"""     def save(self, *args, **kwargs):
	 super(Movie, self).save(*args, **kwargs)
	 filename=self.image.url"""

  
class Cart(models.Model):
	first_name=models.CharField(max_length=200)
	last_name=models.CharField(max_length=200)
	contact_no=models.CharField(max_length=200)
	address=models.CharField(max_length=200)
	def __str__(self):
		return self.first_name





class contactme(models.Model):
	name=models.CharField(max_length=100)
	email=models.CharField(max_length=100)
	m_No=models.CharField(max_length=13)
	message=models.TextField(max_length=1000)
	
	def __str__(self):
		return self.name
		

class UserProfile(models.Model):
    user = models.OneToOneField(User)
    activation_key = models.CharField(max_length=40, blank=True)
    key_expires = models.DateTimeField(default=datetime.date.today())
      
    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural=u'User profiles'


