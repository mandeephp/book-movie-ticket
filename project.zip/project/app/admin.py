from django.contrib import admin

# Register your models here.
#from .models import Post
from .models import *


admin.site.register(UserProfile)

#admin.site.register(Post)
admin.site.register(Movie)
admin.site.register(contactme)
admin.site.register(Cart)
admin.site.register(payment)
