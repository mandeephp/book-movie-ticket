from django.shortcuts import render
# from .models import Post
from .models import Movie
#from forms import BlogForm
from forms import BlogForm1, Contactus
from django.utils import timezone
from django.shortcuts import render_to_response, get_object_or_404
from django.http import HttpResponseRedirect, HttpResponse
from django.contrib import auth
from django.core.context_processors import csrf
from forms import *
from models import *
from django.template import RequestContext
from django.core.mail import send_mail
import hashlib, datetime, random
from django.contrib.auth import authenticate, login
# Create your views here.


def index(request):
	return render(request,'app/index.html',{})

def payments(request):
	return render(request,'app/payment1.html',{})

def civilimage(request):
    i = get_object_or_404(Image, pk=1)
    return render_to_response('app/details.html', {'image': i}, context_instance=RequestContext(request))


######################pay u##################################
"""def payu(request):
	return render(request,'app/payu_form.html',{})"""


#####################pay u##################################3


###############################moviesdatabase#################################
def civilwar(request):
	a = Movie.objects.all()[:1]
	return render(request,'app/details.html',{'a':a})

def zootopia(request):
	a = Movie.objects.all()[1:2]
	return render(request,'app/details.html',{'a':a})

def cloverfieldlane(request):
	a = Movie.objects.all()[2:3]
	return render(request,'app/details.html',{'a':a})

def moneymonster(request):
	a = Movie.objects.all()[3:4]
	return render(request,'app/details.html',{'a':a})

def thedarkness(request):
	a = Movie.objects.all()[4:5]
	return render(request,'app/details.html',{'a':a})


def loveandfriendship(request):
	a = Movie.objects.all()[5:6]
	return render(request,'app/details.html',{'a':a})


def thelobster(request):
	a = Movie.objects.all()[6:7]
	return render(request,'app/details.html',{'a':a})


def waiting(request):
	a = Movie.objects.all()[7:8]
	return render(request,'app/details.html',{'a':a})


def conjuring2(request):
	a = Movie.objects.all()[8:9]
	return render(request,'app/details.html',{'a':a})


def hourstogo(request):
	a = Movie.objects.all()[9:10]
	return render(request,'app/details.html',{'a':a})


def startrekbeyond(request):
	return render(request,'app/details.html',{})


def suicidesquad(request):
	return render(request,'app/details.html',{})


def rustom(request):
	return render(request,'app/details.html',{})


##############################################################################

def details(request):
		a = request.GET['a1']
		movies1 = Movie.objects.filter(id="a")
		#movies1 = Movie.objects.filter(description__icontains=a)
		return render(request, 'app/details.html', {'movies1':movies1})


def search(request):
	if 'q' in request.GET and request.GET['q']:
		q = request.GET['q']
		movies = Movie.objects.filter(movie_name__icontains=q)
		#movies1 = Movie.objects.filter(description__icontains=q)
		return render(request, 'app/search_results.html', {'movies':movies,'query': q})
	else:
		return HttpResponse('Please submit a search term.')



def cart(request):
        i=request.POST.get('mn')
        print(i)
	l= Movie.objects.get(movie_name=i)
	return render(request,'app/cart.html', {'l':l})



def contact(request):
	if request.method=="POST":
		form=Contactus(request.POST)
		if form.is_valid():
			post=form.save(commit=False)
			post.save()
			return render(request,'app/contact1.html',{})
	else:
		form=Contactus()
		return render(request,'app/contact.html',{'form':form})

"""def new(request):
	p=Movie.objects.all()
	return render(request,'app/new.html',{'p':p})"""


####################333online booking#############################################
"""
def zoo(request):
	
	return render(request,'app/xyz.html',{'z':z})

def money(request):
	
	return render(request,'app/online_booking.html',{'m':m})

def darkness(request):
	
	return render(request,'app/online_booking.html',{'d':d})

def clover(request):
	
	return render(request,'app/online_booking.html',{'f':f})

def baagi(request):
	
	return render(request,'app/online_booking.html',{'b':b})

def fan(request):
	
	return render(request,'app/online_booking.html',{'n':n})"""
##################################################################################33

def booking(request):
	c=Movie.objects.filter(id=1)
	z=Movie.objects.filter(id=2)
	m=Movie.objects.filter(id=4)
	d=Movie.objects.filter(id=5)
	f=Movie.objects.filter(id=3)
	b=Movie.objects.filter(id=14)
	n=Movie.objects.filter(id=15)
	return render(request,'app/online_booking.html',{'c':c,'z':z,'d':d,'m':m,'f':f,'b':b,'n':n})

def book(request):
	p=Movie.objects.all()
	return render(request,'app/Book_Movie.html',{})

def movie(request):
	p=Movie.objects.all()
	return render(request,'app/new.html',{'p':p})
  
def trailers(request):
	return render(request,'app/trailers.html',{})
def ongoing(request):
	return render(request,'app/ongoing_movies.html',{})

def about(request):
	return render(request,'app/about_us.html',{})
      

def upcoming(request):
	return render(request,'app/upcoming_movies.html',{})

def register(request):
	return render(request,'app/register.html',{})



def login1(request):
	return render(request,'app/login.html',{})


#################################################################################################
def register_user(request):
    args = {}
    args.update(csrf(request))
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        args['form'] = form
        if form.is_valid(): 
            form.save()  # save user to database if form is valid

            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            salt = hashlib.sha1(str(random.random())).hexdigest()[:5]            
            activation_key = hashlib.sha1(salt+email).hexdigest()            
            key_expires = datetime.datetime.today() + datetime.timedelta(2)

            #Get user by username
            user=User.objects.get(username=username)

            # Create and save user profile                                                                                                                                  
            new_profile = UserProfile(user=user, activation_key=activation_key, 
                key_expires=key_expires)
            new_profile.save()

            # Send email with activation key
            email_subject = 'Account confirmation'
            email_body = "Hey %s, thanks for signing up. To activate your account, click this link within \
            48hours http://127.0.0.1:8000/confirm/%s" % (username, activation_key)

            send_mail(email_subject, email_body, 'myemail@example.com',
                [email], fail_silently=False)

            return render(request,'app/success',{})
    else:
        args['form'] = RegistrationForm()

    return render_to_response('app/register.html', args, context_instance=RequestContext(request))



def register_confirm(request, activation_key):
    #check if user is already logged in and if he is redirect him to some other url, e.g. home
    if request.user.is_authenticated():
        HttpResponseRedirect('/index')

    # check if there is UserProfile which matches the activation key (if not then display 404)
    user_profile = get_object_or_404(UserProfile, activation_key=activation_key)

    #check if the activation key has expired, if it hase then render confirm_expired.html
    if user_profile.key_expires < timezone.now():
        return render_to_response('app/confirm_expired.html')
    #if the key hasn't expired save user and set him as active and render some template to confirm activation
    user = user_profile.user
    user.is_active = True
    user.save()
    return render_to_response('app/confirm.html')

def register_success(request):
    return HttpResponse('successful')

















#email code



def register_user(request):
    args = {}
    args.update(csrf(request))
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        args['form'] = form
        if form.is_valid(): 
            form.save()  # save user to database if form is valid

            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            salt = hashlib.sha1(str(random.random())).hexdigest()[:5]            
            activation_key = hashlib.sha1(salt+email).hexdigest()            
            key_expires = datetime.datetime.today() + datetime.timedelta(2)

            #Get user by username
            user=User.objects.get(username=username)

            # Create and save user profile                                                                                                                                  
            new_profile = UserProfile(user=user, activation_key=activation_key, 
                key_expires=key_expires)
            new_profile.save()

            # Send email with activation key
            email_subject = 'Account confirmation'
            email_body = "Hey %s, thanks for signing up. To activate your account, click this link within \
            48hours http://127.0.0.1:8000/confirm/%s" % (username, activation_key)

            send_mail(email_subject, email_body, 'myemail@example.com',
                [email], fail_silently=False)

            return render(request,'app/success.html',{})
    else:
        args['form'] = RegistrationForm()

    return render_to_response('app/register.html', args, context_instance=RequestContext(request))



def register_confirm(request, activation_key):
    #check if user is already logged in and if he is redirect him to some other url, e.g. home
    if request.user.is_authenticated():
        HttpResponseRedirect('/index')

    # check if there is UserProfile which matches the activation key (if not then display 404)
    user_profile = get_object_or_404(UserProfile, activation_key=activation_key)

    #check if the activation key has expired, if it hase then render confirm_expired.html
    if user_profile.key_expires < timezone.now():
        return render_to_response('myapp/confirm_expired.html')
    #if the key hasn't expired save user and set him as active and render some template to confirm activation
    user = user_profile.user
    user.is_active = True
    user.save()
    return render_to_response('app/confirm.html')

def register_success(request):
    return HttpResponse('successful')

def login1(request):

    if request.method=="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        new_user = authenticate(username=username,password=password)
        if new_user is not None:
            if new_user.is_active:
                login(request,new_user)
                return render(request,'app/index1.html',{'username':username})
            else:
                return HttpResponse("Disabled account")
            
        else:
             return HttpResponse("Invalid Login")


    else:
        return render(request,'app/login.html',{})


def pay(request):
    if request.method=="POST":
        form1=payform(request.POST)
	if form1.is_valid():
	    post=form1.save(commit=False)
	    post.save()
	    return render(request,'app/payment1.html',{})
        
        else:
           form1=payform()
           return render(request,'app/payment.html',{'form1':form1})
    else:
             return HttpResponse("Invalid Login")



